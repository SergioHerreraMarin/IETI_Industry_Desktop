module prueba3 {
	requires java.desktop;
	requires java.xml;
}